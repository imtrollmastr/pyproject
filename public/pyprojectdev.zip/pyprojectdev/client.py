# MUST FINISH

import database
import hashlib
import sqlite3
import json
username = input("Username: ")
password = input("Password: ")
conn = sqlite3.connect("userdata.db")
cur = conn.cursor()
cur.execute("""
CREATE TABLE IF NOT EXISTS userdata (
    id INTEGER PRIMARY KEY,
    username VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL
)            
""")

username1, password1 = username, hashlib.sha256(password.encode()).hexdigest()
cur.execute("INSERT INTO userdata (username, password) VALUES (?, ?)", (username1, password1))
conn.commit()
def main():
    import time
    import webbrowser
    import requests
    import os
    cmdname = "gdysubgvygyus3424tb23vgu42y3b4y23"
    if username1 == database.username1 and password1 == database.password1 or username1 == database.username2 and password1 == database.password2 or username1 == database.username3 and password1 == database.password3 or username1 == database.username4 and password1 == database.password4:
        print("Welcome to PyProject Alpha, a development version of PyProject.")
        print("WARNING: This program mainly runs on MacOS. If you are using Windows or other operating systems, some functions may not work.")
        confirmation = input("Are you sure you would like to continue? (y/n): ")
        if confirmation == "y":
            print("Connecting to server..")
            time.sleep(2)
            print("Now loading assets and content..")
            time.sleep(1)
            print("Welcome to PyProject Alpha")
            i = 0
            while i < 100:
                commandcaller = input("$ ")

                if commandcaller == "spotipy deploy":
                    print("Select a audio number: ")
                    print("1. Lucid (interlude) by BoyWithUke")
                    print("2. Migraine by BoyWithUke")
                    print("3. friday night ####### cover w me and gf by User-177606669, nicopatty, eyes2ears")
                    audionumber = input("Enter AudioNumber: ")
                    if audionumber == "1":
                        os.system("afplay lucid.mp3")
                    elif audionumber == "2":
                        os.system("afplay migrainefull.wav")
                    elif audionumber == "3":
                        os.system("afplay fridaynightfricking.mp3")
                    else:
                        print("Enter valid audio number.")
                elif commandcaller == "openspotify deploy":
                    url = input("Enter Spotify URL: ")
                    data = requests.get("https://open.spotify.com/oembed?url=" + url)
                    x = json.loads(data)
                    print(x)
                elif commandcaller == "ipfinder deploy":
                    import requests
                    import socket
                    hostname = socket.gethostname()
                    ip_address = socket.gethostbyname(hostname)
                    print(f"Hostname: {hostname}")
                    print(f"IP Address: {ip_address}")

                    params = ['query', 'status', 'country', 'countryCode', 'city', 'timezone', 'mobile']
                    resp = requests.get('http://ip-api.com/json/')
                    info = resp.json()
                    if info["org"] == "NordVPN" or info["org"] == "ExpressVPN":
                        print("for security reasons, vpn users cannot access at this point")
                        print("thank you for using ip address locator")
                        break
                    else:
                        pass
                    print(info)
                elif commandcaller == "ropython deploy":
                    import robloxpy
                    unid = input("Enter Universe ID: ")
                    undata = robloxpy.Game.External.GetUniverseData(int(unid))
                    print(undata)
                elif commandcaller == "sqldatabase request":
                    import sqlcaller
                    x = input("Enter saved username: ")
                    y = input("Enter saved password: ")
                    j = input("Enter .DB Filename: ")
                    sqlcaller.sqlcreate(x, y, j)
                    print("Successfully created .db file.")
                elif commandcaller == "avcam deploy":
                    import pygame
                    import pygame.camera
                    pygame.camera.init()
                    camlist = pygame.camera.list_cameras()
                    if camlist:
                        cam = pygame.camera.Camera(camlist[0], (1920, 1080))
                        cam.start()
                        image = cam.get_image()
                        print("Now in HD resolution!")
                        print("Make sure to follow and like @cosyviolin on Instagram!")
                        capname = input("Enter capture image name: ")
                        pygame.image.save(image, capname + ".png")
                        print("Please find the image in PyProject main directory.")
                    else:
                        print("No camera device located.")
                elif commandcaller == "commandplatform deploy":
                    cmdname = input("Enter command name: ")
                    cmdvalue = input("Enter command value: ")
                    print("Successfully created command.")
                elif commandcaller == cmdname:
                    exec(cmdvalue)
                elif commandcaller == "videoclient deploy":
                    import vidclient
                    vidclient.PlayVideo()

        elif confirmation == "n":
            print("Please visit again next time!")
        else:
            print("Please restart and enter a valid value.")
    else:
        print("false")
main()