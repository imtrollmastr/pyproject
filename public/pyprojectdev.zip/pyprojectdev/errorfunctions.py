def loud(x, y, z):
    fruits = [x, y, z]
    loud_fruits = [fruit.upper() for fruit in fruits]
    print(loud_fruits)
def quiet(x, y, z):
    fruits = [x, y, z]
    quiet_fruits = [fruit.lower() for fruit in fruits]
    print(quiet_fruits)
def error(errorcode):
    print("Error Code " + str(errorcode) + ":")
    if errorcode == 400:
        print("Bad Request.")
    elif errorcode == 401:
        print("Unauthorized.")
    elif errorcode == 402:
        print("Payment Required.")
    elif errorcode == 403:
        print("Forbidden.")
    elif errorcode == 404:
        print("Not Found.")
    elif errorcode == 405:
        print("Method Not Allowed")
    elif errorcode == 406:
        print("Not Acceptable.")
    elif errorcode == 407:
        print("Proxy Authentication Required.")
    elif errorcode == 408:
        print("Request Timeout.")
    elif errorcode == 409:
        print("Conflict.")
    elif errorcode == 410:
        print("Gone.")
    elif errorcode == 411:
        print("Length Required.")
    elif errorcode == 412:
        print("Precondition failed.")
    elif errorcode == 413:
        print("Payload too large.")
    elif errorcode == 414:
        print("URI too long.")
    elif errorcode == 415:
        print("Unsupported media type.")
    elif errorcode == 416:
        print("Range not satisfied.")
    elif errorcode == 417:
        print('Expectation failed.')
    elif errorcode == 418:
        print("The requested entity body is short and stout. Tip me over to pour me out.")
    elif errorcode == 421:
        print("Misdirected Request.")
    elif errorcode == 422:
        print("Unproccessable Entity.")
    elif errorcode == 423:
        print("Locked.")
    elif errorcode == 424:
        print("Failed Dependency.")
    elif errorcode == 425:
        print("Too Early.")
    elif errorcode == 426:
        print("Update required.")
    elif errorcode == 428:
        print("Precondition Required.")
    elif errorcode == 429:
        print("Too many requests.")
    elif errorcode == 431:
        print("Request Header Fields Too Large.")
    elif errorcode == 451:
        print("PyProject Alpha is not available in your location.")
    else:
        print("Developer Notice: Invalid Error Code")
        pass
    