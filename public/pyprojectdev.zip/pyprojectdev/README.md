# PyProject Alpha (Development Stage)
Thank you for purchasing PyProject Alpha, we appreciate your support.
By running any of our programs, you agree to our terms and conditions.

# How to use our programs
First of all, install Visual Studio Code if you haven't. Then open this folder in VS Code. If you're on VS Code, that's great! Now, run this command:
```
bash install.sh
```
After that, you might see some things installing. Those are the programs needed for the code to run. Please wait patiently until it pops out:
```
Username: 
```
Then enter your given username and password, then you ready to go. If you need support with commands, you may continue reading this README file.

# Commands
```
spotipy deploy
```
This command allows you to listen to integrated/built-in music. So far, there are only 3 choices.
```
ipfinder deploy
```
This command lets you read the information on your IP address and hostname. However, if you are currently using a VPN, you may not be able to read information about your IP address.
```
ropython deploy
```
This command uses the provided universe ID to find information on the Roblox game.
```
avcam deploy
```
Takes a picture using your laptop and writing it into this folder.
# Credits
imtrollmastr - Scripting & Graphics

