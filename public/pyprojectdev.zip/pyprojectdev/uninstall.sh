python3 -m pip uninstall opencv-python
python3 -m pip uninstall numpy
python3 -m pip uninstall requests
python3 -m pip uninstall pygame
python3 -m pip uninstall robloxpy
say Successfully uninstalled programs